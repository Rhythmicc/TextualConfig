#!/usr/bin/env python
# -*- coding: utf-8 -*-

name = "TextualConfig"
from .src import Config
